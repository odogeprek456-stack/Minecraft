# Minecraft No-License (Demo)

Game voxel open world sederhana untuk Android, ditulis dengan Java + OpenGL ES 2.0.
Semua tekstur digambar lewat kode (tanpa aset dari game mana pun).

## Cara membuat APK

**A. GitHub Actions (tanpa komputer, bisa dari HP)**
1. Buat repository baru di GitHub, unggah seluruh isi folder ini (termasuk folder `.github`).
2. Buka tab **Actions** -> workflow **Build APK** (jalan otomatis saat push, atau klik *Run workflow*).
3. Setelah selesai, unduh artifact **Minecraft-No-License-apk** -> berisi `app-debug.apk`.

**B. Android Studio**
1. File -> Open -> pilih folder ini, tunggu Gradle sync (JDK 17).
2. Build -> Build APK(s). Hasil: `app/build/outputs/apk/debug/app-debug.apk`.

**C. Command line** (butuh Android SDK + JDK 17): `./gradlew assembleDebug`

Instal APK di HP (izinkan "install dari sumber tidak dikenal").

## Kontrol
- Analog kiri: berjalan ke segala arah
- Geser jari di sisi kanan layar: memutar kamera
- **Lompat**, **Hancur** (tahan untuk terus menghancurkan), **Pasang**
- Hotbar bawah: ketuk untuk memilih blok
- Tombol **II** / Back: menu jeda

## Isi demo
- Menu utama: Buat Dunia (seed opsional) dan Pengaturan (jarak pandang, sensitivitas, FPS)
- Dunia tanpa batas, dibuat dari seed: dataran, bukit, pegunungan, pantai berpasir, pohon
- 8 jenis blok; edit dunia tersimpan selama game berjalan (belum ada simpan ke file)

## Struktur kode (`app/src/main/java/com/nolicense/craft`)
- `World`, `Chunk`, `Noise`, `Block`: data dunia, pembuatan terrain, mesh, raycast (Java murni)
- `Player`, `Input`: fisika, tabrakan, gravitasi, lompat
- `GameRenderer`: game loop + render OpenGL ES 2.0 (chunk streaming, kabut)
- `ControlsView`: analog, tombol, hotbar, HUD
- `MainActivity`, `SettingsActivity`, `GameActivity`, `Ui`, `TextureAtlas`

## Catatan
Nama "Minecraft" adalah merek dagang Mojang/Microsoft. Untuk dipublikasikan (mis. Play Store),
ganti nama game di `AndroidManifest.xml` dan `MainActivity.java`.
