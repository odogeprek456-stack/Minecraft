package com.nolicense.craft;

/** Status kontrol bersama antara thread UI (sentuhan) dan thread GL (game loop). */
public final class Input {
    public volatile float moveX, moveY;           // analog: -1..1 (moveY +1 = maju)
    public volatile boolean jump, breakHeld, placeHeld;
    public volatile int selected = 0;             // slot hotbar terpilih

    private float lookDx, lookDy;

    public synchronized void addLook(float dx, float dy) {
        lookDx += dx;
        lookDy += dy;
    }

    public synchronized void takeLook(float[] out) {
        out[0] = lookDx;
        out[1] = lookDy;
        lookDx = 0f;
        lookDy = 0f;
    }
}
