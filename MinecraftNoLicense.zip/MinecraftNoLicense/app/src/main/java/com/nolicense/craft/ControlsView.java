package com.nolicense.craft;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

/**
 * Lapisan kontrol sentuh di atas GLSurfaceView:
 * analog kiri (gerak), geser di sisi kanan (kamera), tombol Lompat/Hancur/Pasang, hotbar, dan HUD.
 */
public class ControlsView extends View {
    private final Input input;
    private final GameRenderer renderer;
    private final Runnable onPause;
    private final boolean showFps;
    private final float dp;

    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint icon = new Paint();
    private final Rect src = new Rect();
    private final RectF dst = new RectF();

    // pointer yang sedang aktif
    private int joyId = -1, lookId = -1, jumpId = -1, breakId = -1, placeId = -1;

    // analog
    private float joyR, joyHomeX, joyHomeY, joyCx, joyCy, joyX, joyY;
    // tombol (pusat + radius)
    private float jumpX, jumpY, jumpR, breakX, breakY, breakR, placeX, placeY, placeR;
    private float pauseX, pauseY, pauseR;
    // hotbar
    private float slot, barX, barY;
    private float lastLx, lastLy;

    public ControlsView(Context c, Input input, GameRenderer renderer, boolean showFps, Runnable onPause) {
        super(c);
        this.input = input;
        this.renderer = renderer;
        this.showFps = showFps;
        this.onPause = onPause;
        this.dp = c.getResources().getDisplayMetrics().density;

        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(2f * dp);
        text.setColor(Color.WHITE);
        text.setTextAlign(Paint.Align.CENTER);
        text.setFakeBoldText(true);
        text.setShadowLayer(3f, 1f, 1f, 0xFF000000);
        icon.setFilterBitmap(false);
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        joyR = 55f * dp;
        joyHomeX = 40f * dp + joyR * 1.2f;
        joyHomeY = h - 30f * dp - joyR * 1.2f;
        joyCx = joyHomeX; joyCy = joyHomeY; joyX = joyCx; joyY = joyCy;

        jumpR = 40f * dp;
        jumpX = w - 36f * dp - jumpR;
        jumpY = h - 30f * dp - jumpR;
        breakR = 32f * dp;
        breakX = jumpX - jumpR - breakR - 14f * dp;
        breakY = h - 30f * dp - breakR;
        placeR = 32f * dp;
        placeX = jumpX;
        placeY = jumpY - jumpR - placeR - 14f * dp;

        pauseR = 20f * dp;
        pauseX = w - 20f * dp - pauseR;
        pauseY = 14f * dp + pauseR;

        slot = Math.min(46f * dp, (w * 0.5f) / Block.HOTBAR.length);
        barX = (w - slot * Block.HOTBAR.length) / 2f;
        barY = h - slot - 8f * dp;
    }

    private static boolean in(float x, float y, float cx, float cy, float r) {
        float dx = x - cx, dy = y - cy;
        return dx * dx + dy * dy <= r * r;
    }

    // ================= sentuhan =================

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int a = e.getActionMasked();
        int idx = e.getActionIndex();
        switch (a) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_POINTER_DOWN:
                down(e.getPointerId(idx), e.getX(idx), e.getY(idx));
                break;
            case MotionEvent.ACTION_MOVE:
                for (int i = 0; i < e.getPointerCount(); i++)
                    move(e.getPointerId(i), e.getX(i), e.getY(i));
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_POINTER_UP:
                up(e.getPointerId(idx));
                break;
            case MotionEvent.ACTION_CANCEL:
                releaseAll();
                break;
            default:
                break;
        }
        invalidate();
        return true;
    }

    private void down(int id, float x, float y) {
        if (in(x, y, pauseX, pauseY, pauseR * 1.3f)) {
            releaseAll();
            onPause.run();
            return;
        }
        // hotbar
        if (y >= barY && y <= barY + slot && x >= barX && x <= barX + slot * Block.HOTBAR.length) {
            input.selected = Math.min(Block.HOTBAR.length - 1, (int) ((x - barX) / slot));
            return;
        }
        if (jumpId < 0 && in(x, y, jumpX, jumpY, jumpR * 1.25f)) {
            jumpId = id;
            input.jump = true;
        } else if (breakId < 0 && in(x, y, breakX, breakY, breakR * 1.25f)) {
            breakId = id;
            input.breakHeld = true;
        } else if (placeId < 0 && in(x, y, placeX, placeY, placeR * 1.25f)) {
            placeId = id;
            input.placeHeld = true;
        } else if (joyId < 0 && x < getWidth() / 2f) {
            joyId = id;
            joyCx = x; joyCy = y; joyX = x; joyY = y;
            input.moveX = 0f;
            input.moveY = 0f;
        } else if (lookId < 0 && x >= getWidth() / 2f) {
            lookId = id;
            lastLx = x; lastLy = y;
        }
    }

    private void move(int id, float x, float y) {
        if (id == joyId) {
            float dx = x - joyCx, dy = y - joyCy;
            float len = (float) Math.sqrt(dx * dx + dy * dy);
            if (len > joyR) {
                dx = dx / len * joyR;
                dy = dy / len * joyR;
            }
            joyX = joyCx + dx;
            joyY = joyCy + dy;
            float nx = dx / joyR, ny = -dy / joyR;
            float mag = (float) Math.sqrt(nx * nx + ny * ny);
            if (mag < 0.12f) { nx = 0f; ny = 0f; }
            input.moveX = nx;
            input.moveY = ny;
        } else if (id == lookId) {
            input.addLook(x - lastLx, y - lastLy);
            lastLx = x;
            lastLy = y;
        }
    }

    private void up(int id) {
        if (id == joyId) {
            joyId = -1;
            joyCx = joyHomeX; joyCy = joyHomeY; joyX = joyCx; joyY = joyCy;
            input.moveX = 0f;
            input.moveY = 0f;
        } else if (id == lookId) {
            lookId = -1;
        } else if (id == jumpId) {
            jumpId = -1;
            input.jump = false;
        } else if (id == breakId) {
            breakId = -1;
            input.breakHeld = false;
        } else if (id == placeId) {
            placeId = -1;
            input.placeHeld = false;
        }
    }

    public void releaseAll() {
        joyId = lookId = jumpId = breakId = placeId = -1;
        joyCx = joyHomeX; joyCy = joyHomeY; joyX = joyCx; joyY = joyCy;
        input.moveX = 0f;
        input.moveY = 0f;
        input.jump = false;
        input.breakHeld = false;
        input.placeHeld = false;
    }

    // ================= gambar =================

    private void button(Canvas c, float x, float y, float r, String label, boolean pressed) {
        fill.setColor(pressed ? 0x88FFFFFF : 0x44FFFFFF);
        c.drawCircle(x, y, r, fill);
        stroke.setColor(0xAAFFFFFF);
        c.drawCircle(x, y, r, stroke);
        text.setTextSize(r * 0.38f);
        c.drawText(label, x, y + r * 0.14f, text);
    }

    @Override
    protected void onDraw(Canvas c) {
        int w = getWidth(), h = getHeight();

        // crosshair
        stroke.setColor(0xDDFFFFFF);
        float cx = w / 2f, cy = h / 2f, arm = 9f * dp;
        c.drawLine(cx - arm, cy, cx + arm, cy, stroke);
        c.drawLine(cx, cy - arm, cx, cy + arm, stroke);

        // analog
        fill.setColor(0x33FFFFFF);
        c.drawCircle(joyCx, joyCy, joyR, fill);
        stroke.setColor(0x99FFFFFF);
        c.drawCircle(joyCx, joyCy, joyR, stroke);
        fill.setColor(joyId >= 0 ? 0xAAFFFFFF : 0x77FFFFFF);
        c.drawCircle(joyX, joyY, joyR * 0.42f, fill);

        // tombol
        button(c, jumpX, jumpY, jumpR, "Lompat", jumpId >= 0);
        button(c, breakX, breakY, breakR, "Hancur", breakId >= 0);
        button(c, placeX, placeY, placeR, "Pasang", placeId >= 0);
        button(c, pauseX, pauseY, pauseR, "II", false);

        // hotbar
        Bitmap atlas = TextureAtlas.get();
        for (int i = 0; i < Block.HOTBAR.length; i++) {
            float x = barX + i * slot;
            fill.setColor(0x99000000);
            c.drawRect(x, barY, x + slot, barY + slot, fill);
            int t = Block.iconTile(Block.HOTBAR[i]);
            int sx = (t % TextureAtlas.COLS) * TextureAtlas.TILE, sy = (t / TextureAtlas.COLS) * TextureAtlas.TILE;
            src.set(sx, sy, sx + TextureAtlas.TILE, sy + TextureAtlas.TILE);
            float pad = slot * 0.16f;
            dst.set(x + pad, barY + pad, x + slot - pad, barY + slot - pad);
            c.drawBitmap(atlas, src, dst, icon);
            stroke.setColor(i == input.selected ? 0xFFFFFFFF : 0x88888888);
            stroke.setStrokeWidth((i == input.selected ? 3.5f : 1.5f) * dp);
            c.drawRect(x, barY, x + slot, barY + slot, stroke);
        }
        stroke.setStrokeWidth(2f * dp);

        // nama blok terpilih
        text.setTextSize(13f * dp);
        c.drawText(Block.name(Block.HOTBAR[input.selected]), w / 2f, barY - 6f * dp, text);

        // HUD
        if (showFps) {
            text.setTextAlign(Paint.Align.LEFT);
            text.setTextSize(12f * dp);
            c.drawText("FPS " + renderer.fps, 10f * dp, 20f * dp, text);
            c.drawText(String.format("XYZ %.1f / %.1f / %.1f", renderer.posX, renderer.posY, renderer.posZ),
                    10f * dp, 36f * dp, text);
            text.setTextAlign(Paint.Align.CENTER);
        }

        postInvalidateDelayed(100);   // segarkan FPS/koordinat
    }
}
