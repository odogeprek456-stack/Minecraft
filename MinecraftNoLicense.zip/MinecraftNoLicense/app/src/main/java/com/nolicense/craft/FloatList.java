package com.nolicense.craft;

/** Array float yang bisa membesar, dipakai untuk membangun mesh tanpa alokasi berulang. */
public final class FloatList {
    public float[] data = new float[1 << 16];
    public int size = 0;

    public void clear() {
        size = 0;
    }

    public void add(float a, float b, float c, float d, float e, float f) {
        if (size + 6 > data.length) {
            float[] n = new float[data.length * 2];
            System.arraycopy(data, 0, n, 0, size);
            data = n;
        }
        data[size++] = a;
        data[size++] = b;
        data[size++] = c;
        data[size++] = d;
        data[size++] = e;
        data[size++] = f;
    }
}
