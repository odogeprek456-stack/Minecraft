package com.nolicense.craft;

/** Pemain: fisika, gravitasi, lompat, dan tabrakan AABB dengan blok. */
public final class Player {
    public static final float W = 0.6f, HEIGHT = 1.8f, EYE = 1.62f;
    private static final float SPEED = 4.6f, GRAVITY = 28f, JUMP_V = 8.6f;

    public float x, y, z;     // posisi kaki
    public float vy;
    public float yaw, pitch;  // derajat; yaw 0 = menghadap -Z
    public boolean onGround;

    private final World world;

    public Player(World world) {
        this.world = world;
    }

    public void teleport(float nx, float ny, float nz) {
        x = nx; y = ny; z = nz; vy = 0f;
    }

    /** strafe: -1 kiri..1 kanan, fwd: -1 mundur..1 maju. */
    public void update(float dt, float strafe, float fwd, boolean jump) {
        double yr = Math.toRadians(yaw);
        float s = (float) Math.sin(yr), c = (float) Math.cos(yr);
        float wx = s * fwd + c * strafe;
        float wz = -c * fwd + s * strafe;
        float len = (float) Math.sqrt(wx * wx + wz * wz);
        if (len > 1f) { wx /= len; wz /= len; }

        vy -= GRAVITY * dt;
        if (vy < -50f) vy = -50f;
        if (jump && onGround) vy = JUMP_V;

        onGround = false;
        moveAxis(0, wx * SPEED * dt);
        moveAxis(2, wz * SPEED * dt);
        moveAxis(1, vy * dt);

        if (y < -30f) {
            int sy = world.surfaceY((int) Math.floor(x), (int) Math.floor(z));
            teleport(x, sy + 0.01f, z);
        }
    }

    private void moveAxis(int axis, float d) {
        if (d == 0f) return;
        int n = (int) Math.ceil(Math.abs(d) / 0.2f);
        float s = d / n;
        for (int i = 0; i < n; i++) {
            if (!tryMove(axis, s)) {
                float ss = s;
                for (int k = 0; k < 7; k++) {   // rapatkan ke permukaan
                    ss *= 0.5f;
                    tryMove(axis, ss);
                }
                if (axis == 1) {
                    if (d < 0f) onGround = true;
                    vy = 0f;
                }
                return;
            }
        }
    }

    private boolean tryMove(int axis, float s) {
        float nx = x + (axis == 0 ? s : 0f);
        float ny = y + (axis == 1 ? s : 0f);
        float nz = z + (axis == 2 ? s : 0f);
        if (collides(nx, ny, nz)) return false;
        x = nx; y = ny; z = nz;
        return true;
    }

    private boolean collides(float px, float py, float pz) {
        float h = W / 2f;
        int x0 = (int) Math.floor(px - h), x1 = (int) Math.floor(px + h - 1e-4f);
        int y0 = (int) Math.floor(py), y1 = (int) Math.floor(py + HEIGHT - 1e-4f);
        int z0 = (int) Math.floor(pz - h), z1 = (int) Math.floor(pz + h - 1e-4f);
        for (int by = y0; by <= y1; by++)
            for (int bz = z0; bz <= z1; bz++)
                for (int bx = x0; bx <= x1; bx++)
                    if (world.isSolid(bx, by, bz)) return true;
        return false;
    }

    /** Apakah kotak blok (bx,by,bz) bersinggungan dengan tubuh pemain? */
    public boolean overlapsBlock(int bx, int by, int bz) {
        float h = W / 2f;
        return x + h > bx && x - h < bx + 1 && y + HEIGHT > by && y < by + 1
                && z + h > bz && z - h < bz + 1;
    }
}
