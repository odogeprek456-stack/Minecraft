package com.nolicense.craft;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;

/** Dunia open world tanpa batas horizontal; chunk dibuat saat dibutuhkan. */
public final class World {
    public static final int CS = 16;
    public static final int H = 64;

    public final long seed;
    private final Noise noise;
    private final HashMap<Long, Chunk> chunks = new HashMap<>();

    /** Chunk yang berubah karena edit pemain; renderer membangun ulang meshnya. */
    public final ArrayList<Chunk> edited = new ArrayList<>();

    public static final class Hit {
        public int x, y, z;     // blok yang terkena
        public int px, py, pz;  // blok kosong tepat di depan permukaan yang terkena
    }

    public World(long seed) {
        this.seed = seed;
        this.noise = new Noise(seed);
    }

    // ---------- akses chunk ----------

    private static long key(int cx, int cz) {
        return ((long) cx << 32) | (cz & 0xFFFFFFFFL);
    }

    static int idx(int x, int y, int z) {
        return (y * CS + z) * CS + x;
    }

    public Chunk getChunk(int cx, int cz) {
        return chunks.get(key(cx, cz));
    }

    public Chunk ensureChunk(int cx, int cz) {
        long k = key(cx, cz);
        Chunk c = chunks.get(k);
        if (c == null) {
            c = new Chunk(cx, cz);
            generate(c);
            chunks.put(k, c);
        }
        return c;
    }

    public void ensureAround(int cx, int cz, int r) {
        for (int dz = -r; dz <= r; dz++)
            for (int dx = -r; dx <= r; dx++)
                ensureChunk(cx + dx, cz + dz);
    }

    public Collection<Chunk> chunkValues() {
        return chunks.values();
    }

    public void removeChunk(Chunk c) {
        chunks.remove(key(c.cx, c.cz));
    }

    // ---------- akses blok ----------

    public byte getBlock(int x, int y, int z) {
        if (y < 0 || y >= H) return Block.AIR;
        Chunk c = getChunk(x >> 4, z >> 4);
        if (c == null) return Block.AIR;
        return c.blocks[idx(x & 15, y, z & 15)];
    }

    /** Untuk tabrakan: chunk yang belum dimuat dianggap padat agar pemain tidak jatuh ke void. */
    public boolean isSolid(int x, int y, int z) {
        if (y < 0) return true;
        if (y >= H) return false;
        Chunk c = getChunk(x >> 4, z >> 4);
        if (c == null) return true;
        return c.blocks[idx(x & 15, y, z & 15)] != Block.AIR;
    }

    public boolean setBlock(int x, int y, int z, byte b) {
        if (y < 0 || y >= H) return false;
        int cx = x >> 4, cz = z >> 4;
        Chunk c = getChunk(cx, cz);
        if (c == null) return false;
        int lx = x & 15, lz = z & 15;
        c.blocks[idx(lx, y, lz)] = b;
        c.modified = true;
        markEdited(c);
        if (lx == 0) markEdited(getChunk(cx - 1, cz));
        if (lx == CS - 1) markEdited(getChunk(cx + 1, cz));
        if (lz == 0) markEdited(getChunk(cx, cz - 1));
        if (lz == CS - 1) markEdited(getChunk(cx, cz + 1));
        return true;
    }

    private void markEdited(Chunk c) {
        if (c != null && !edited.contains(c)) edited.add(c);
    }

    /** Y kosong pertama di atas permukaan pada kolom (x, z). Chunk harus sudah ada. */
    public int surfaceY(int x, int z) {
        for (int y = H - 1; y >= 0; y--) {
            if (getBlock(x, y, z) != Block.AIR) return y + 1;
        }
        return 1;
    }

    // ---------- pembuatan terrain ----------

    private void generate(Chunk c) {
        byte[] b = c.blocks;
        int ox = c.cx * CS, oz = c.cz * CS;
        int[] heights = new int[CS * CS];

        for (int z = 0; z < CS; z++) {
            for (int x = 0; x < CS; x++) {
                int wx = ox + x, wz = oz + z;
                float n = noise.fbm(wx / 60f, wz / 60f, 4);
                float m = noise.fbm(wx / 200f + 500f, wz / 200f - 300f, 3);
                int h = (int) (20f + n * 26f + Math.max(0f, m - 0.5f) * 60f);
                if (h < 4) h = 4;
                if (h > 54) h = 54;
                heights[z * CS + x] = h;

                boolean beach = h <= 27;
                boolean rocky = h >= 44;
                for (int y = 0; y <= h; y++) {
                    byte t;
                    if (y == 0) t = Block.BEDROCK;
                    else if (y < h - 3) t = Block.STONE;
                    else if (y < h) t = beach ? Block.SAND : (rocky ? Block.STONE : Block.DIRT);
                    else t = beach ? Block.SAND : (rocky ? Block.STONE : Block.GRASS);
                    b[idx(x, y, z)] = t;
                }
            }
        }

        // Pohon: hanya di dalam chunk agar tajuk tidak melewati batas chunk.
        for (int z = 2; z <= 13; z++) {
            for (int x = 2; x <= 13; x++) {
                int h = heights[z * CS + x];
                if (b[idx(x, h, z)] != Block.GRASS) continue;
                int wx = ox + x, wz = oz + z;
                if (noise.rand(wx * 3 + 1, wz * 3 + 7) < 0.985f) continue;
                int th = 4 + (int) (noise.rand(wz, wx) * 2f);
                for (int ly = h + th - 2; ly <= h + th + 1; ly++) {
                    int r = (ly >= h + th) ? 1 : 2;
                    for (int dz = -r; dz <= r; dz++) {
                        for (int dx = -r; dx <= r; dx++) {
                            if (r == 2 && Math.abs(dx) == 2 && Math.abs(dz) == 2) continue;
                            if (b[idx(x + dx, ly, z + dz)] == Block.AIR)
                                b[idx(x + dx, ly, z + dz)] = Block.LEAVES;
                        }
                    }
                }
                for (int ty = h + 1; ty <= h + th; ty++) b[idx(x, ty, z)] = Block.WOOD;
            }
        }
    }

    // ---------- pembuatan mesh ----------

    private static final int[] FDX = {1, -1, 0, 0, 0, 0};
    private static final int[] FDY = {0, 0, 1, -1, 0, 0};
    private static final int[] FDZ = {0, 0, 0, 0, 1, -1};
    private static final float[] SHADE = {0.80f, 0.80f, 1.00f, 0.55f, 0.65f, 0.65f};

    // 4 sudut per sisi (x,y,z), urutan: kiri-bawah, kanan-bawah, kanan-atas, kiri-atas
    private static final int[][] CORNERS = {
            {1, 0, 1, 1, 0, 0, 1, 1, 0, 1, 1, 1}, // +X
            {0, 0, 0, 0, 0, 1, 0, 1, 1, 0, 1, 0}, // -X
            {0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 0}, // +Y
            {0, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0, 1}, // -Y
            {0, 0, 1, 1, 0, 1, 1, 1, 1, 0, 1, 1}, // +Z
            {1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 1, 0}, // -Z
    };
    private static final int[] UVU = {0, 1, 1, 0};
    private static final int[] UVV = {1, 1, 0, 0};
    private static final float EPS = 0.001f;

    private static byte neighborBlock(byte[] bl, Chunk[] nb, int x, int y, int z) {
        if (y < 0) return 1;
        if (y >= H) return 0;
        if (x < 0) {
            Chunk n = nb[0];
            return n == null ? 0 : n.blocks[idx(x + CS, y, z)];
        }
        if (x >= CS) {
            Chunk n = nb[1];
            return n == null ? 0 : n.blocks[idx(x - CS, y, z)];
        }
        if (z < 0) {
            Chunk n = nb[2];
            return n == null ? 0 : n.blocks[idx(x, y, z + CS)];
        }
        if (z >= CS) {
            Chunk n = nb[3];
            return n == null ? 0 : n.blocks[idx(x, y, z - CS)];
        }
        return bl[idx(x, y, z)];
    }

    /** Bangun mesh chunk: 6 float per vertex (x, y, z, u, v, bayangan), 6 vertex per sisi. */
    public void buildMesh(Chunk c, FloatList out) {
        out.clear();
        Chunk[] nb = {getChunk(c.cx - 1, c.cz), getChunk(c.cx + 1, c.cz),
                getChunk(c.cx, c.cz - 1), getChunk(c.cx, c.cz + 1)};
        byte[] bl = c.blocks;
        int ox = c.cx * CS, oz = c.cz * CS;
        for (int y = 0; y < H; y++) {
            for (int z = 0; z < CS; z++) {
                for (int x = 0; x < CS; x++) {
                    byte b = bl[idx(x, y, z)];
                    if (b == Block.AIR) continue;
                    for (int f = 0; f < 6; f++) {
                        if (neighborBlock(bl, nb, x + FDX[f], y + FDY[f], z + FDZ[f]) != Block.AIR)
                            continue;
                        int face = f == 2 ? 0 : (f == 3 ? 2 : 1);
                        addFace(out, f, ox + x, y, oz + z, Block.tile(b, face), SHADE[f]);
                    }
                }
            }
        }
    }

    private static void addFace(FloatList out, int f, int x, int y, int z, int tile, float shade) {
        float u0 = (tile % 4) * 0.25f + EPS;
        float v0 = (tile / 4) * 0.25f + EPS;
        float size = 0.25f - 2f * EPS;
        int[] cn = CORNERS[f];
        float[] px = new float[4], py = new float[4], pz = new float[4], pu = new float[4], pv = new float[4];
        for (int k = 0; k < 4; k++) {
            px[k] = x + cn[k * 3];
            py[k] = y + cn[k * 3 + 1];
            pz[k] = z + cn[k * 3 + 2];
            pu[k] = u0 + UVU[k] * size;
            pv[k] = v0 + UVV[k] * size;
        }
        int[] order = {0, 1, 2, 0, 2, 3};
        for (int i : order) out.add(px[i], py[i], pz[i], pu[i], pv[i], shade);
    }

    // ---------- raycast (DDA voxel) ----------

    public boolean raycast(float ox, float oy, float oz, float dx, float dy, float dz,
                           float maxDist, Hit out) {
        int x = (int) Math.floor(ox), y = (int) Math.floor(oy), z = (int) Math.floor(oz);
        int sx = dx > 0 ? 1 : -1, sy = dy > 0 ? 1 : -1, sz = dz > 0 ? 1 : -1;
        float inf = Float.POSITIVE_INFINITY;
        float tdx = dx == 0 ? inf : Math.abs(1f / dx);
        float tdy = dy == 0 ? inf : Math.abs(1f / dy);
        float tdz = dz == 0 ? inf : Math.abs(1f / dz);
        float tmx = dx == 0 ? inf : (dx > 0 ? (x + 1 - ox) : (ox - x)) * tdx;
        float tmy = dy == 0 ? inf : (dy > 0 ? (y + 1 - oy) : (oy - y)) * tdy;
        float tmz = dz == 0 ? inf : (dz > 0 ? (z + 1 - oz) : (oz - z)) * tdz;
        int px = x, py = y, pz = z;
        float t = 0f;
        while (t <= maxDist) {
            if (getBlock(x, y, z) != Block.AIR) {
                out.x = x; out.y = y; out.z = z;
                out.px = px; out.py = py; out.pz = pz;
                return true;
            }
            px = x; py = y; pz = z;
            if (tmx < tmy && tmx < tmz) {
                x += sx; t = tmx; tmx += tdx;
            } else if (tmy < tmz) {
                y += sy; t = tmy; tmy += tdy;
            } else {
                z += sz; t = tmz; tmz += tdz;
            }
        }
        return false;
    }
}
