package com.nolicense.craft;

import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.GLUtils;
import android.opengl.Matrix;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.ArrayList;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

/** Game loop + render OpenGL ES 2.0. Semua logika game berjalan di thread GL. */
public class GameRenderer implements GLSurfaceView.Renderer {
    private static final float SKY_R = 0.53f, SKY_G = 0.81f, SKY_B = 0.92f;
    private static final float REACH = 5f;

    private static final String VS =
            "uniform mat4 uMVP; uniform vec3 uCam; uniform float uFogStart; uniform float uFogEnd;\n"
                    + "attribute vec3 aPos; attribute vec2 aUV; attribute float aShade;\n"
                    + "varying vec2 vUV; varying float vShade; varying float vFog;\n"
                    + "void main(){\n"
                    + "  gl_Position = uMVP * vec4(aPos, 1.0);\n"
                    + "  vUV = aUV; vShade = aShade;\n"
                    + "  float d = length(aPos - uCam);\n"
                    + "  vFog = clamp((d - uFogStart) / (uFogEnd - uFogStart), 0.0, 1.0);\n"
                    + "}\n";
    private static final String FS =
            "precision mediump float;\n"
                    + "uniform sampler2D uTex; uniform vec3 uFogColor;\n"
                    + "varying vec2 vUV; varying float vShade; varying float vFog;\n"
                    + "void main(){\n"
                    + "  vec4 c = texture2D(uTex, vUV);\n"
                    + "  gl_FragColor = vec4(mix(c.rgb * vShade, uFogColor, vFog), 1.0);\n"
                    + "}\n";
    private static final String LVS =
            "uniform mat4 uMVP; attribute vec3 aPos;\n"
                    + "void main(){ gl_Position = uMVP * vec4(aPos, 1.0); }\n";
    private static final String LFS =
            "precision mediump float;\n"
                    + "void main(){ gl_FragColor = vec4(0.0, 0.0, 0.0, 1.0); }\n";

    // ---- state game ----
    private final World world;
    private final Player player;
    private final Input input;
    private final int renderDist;
    private final float sens;

    public volatile boolean paused = false;
    public volatile int fps = 0;
    public volatile float posX, posY, posZ;

    private boolean initialized = false;
    private long lastNs = 0;
    private float breakCd = 0f, placeCd = 0f;
    private final float[] look = new float[2];
    private final World.Hit hit = new World.Hit();
    private boolean hasHit = false;

    private int lastCx = Integer.MIN_VALUE, lastCz = Integer.MIN_VALUE;
    private boolean needScan = true;

    // ---- GL ----
    private int prog, uMVP, uCam, uFogStart, uFogEnd, uTex, uFogColor, aPos, aUV, aShade;
    private int lineProg, luMVP, laPos;
    private int texture;
    private final float[] proj = new float[16], view = new float[16], vp = new float[16], tmp = new float[16];
    private float aspect = 1.7f;
    private int frames = 0;
    private long fpsStart = 0;

    private ByteBuffer scratch = ByteBuffer.allocateDirect(1 << 20).order(ByteOrder.nativeOrder());
    private final FloatList meshList = new FloatList();
    private final FloatBuffer outline;

    public GameRenderer(World world, Input input, int renderDist, float sens) {
        this.world = world;
        this.player = new Player(world);
        this.input = input;
        this.renderDist = renderDist;
        this.sens = sens;

        float a = -0.003f, b = 1.003f;
        float[] v = {
                a, a, a, b, a, a, b, a, a, b, a, b, b, a, b, a, a, b, a, a, b, a, a, a,
                a, b, a, b, b, a, b, b, a, b, b, b, b, b, b, a, b, b, a, b, b, a, b, a,
                a, a, a, a, b, a, b, a, a, b, b, a, b, a, b, b, b, b, a, a, b, a, b, b,
        };
        outline = ByteBuffer.allocateDirect(v.length * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
        outline.put(v).position(0);
    }

    // ================= siklus GL =================

    @Override
    public void onSurfaceCreated(GL10 gl, EGLConfig config) {
        GLES20.glClearColor(SKY_R, SKY_G, SKY_B, 1f);
        GLES20.glEnable(GLES20.GL_DEPTH_TEST);

        prog = program(VS, FS);
        uMVP = GLES20.glGetUniformLocation(prog, "uMVP");
        uCam = GLES20.glGetUniformLocation(prog, "uCam");
        uFogStart = GLES20.glGetUniformLocation(prog, "uFogStart");
        uFogEnd = GLES20.glGetUniformLocation(prog, "uFogEnd");
        uTex = GLES20.glGetUniformLocation(prog, "uTex");
        uFogColor = GLES20.glGetUniformLocation(prog, "uFogColor");
        aPos = GLES20.glGetAttribLocation(prog, "aPos");
        aUV = GLES20.glGetAttribLocation(prog, "aUV");
        aShade = GLES20.glGetAttribLocation(prog, "aShade");

        lineProg = program(LVS, LFS);
        luMVP = GLES20.glGetUniformLocation(lineProg, "uMVP");
        laPos = GLES20.glGetAttribLocation(lineProg, "aPos");

        int[] t = new int[1];
        GLES20.glGenTextures(1, t, 0);
        texture = t[0];
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texture);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_NEAREST);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_NEAREST);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE);
        GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, TextureAtlas.get(), 0);

        // Konteks baru: semua VBO lama tidak valid -> bangun ulang mesh.
        for (Chunk c : world.chunkValues()) {
            c.vbo = 0;
            c.vertexCount = 0;
            c.meshed = false;
        }
        needScan = true;
        lastNs = System.nanoTime();
        fpsStart = lastNs;
    }

    @Override
    public void onSurfaceChanged(GL10 gl, int w, int h) {
        GLES20.glViewport(0, 0, w, h);
        aspect = (float) w / Math.max(1, h);
    }

    @Override
    public void onDrawFrame(GL10 gl) {
        long now = System.nanoTime();
        float dt = Math.min(0.05f, (now - lastNs) / 1e9f);
        lastNs = now;

        if (!initialized) initWorld();
        if (!paused) update(dt);
        streamChunks();
        render();

        frames++;
        if (now - fpsStart >= 500_000_000L) {
            fps = (int) (frames * 1e9f / (now - fpsStart));
            frames = 0;
            fpsStart = now;
        }
    }

    // ================= logika game =================

    private void initWorld() {
        world.ensureAround(0, 0, 2);
        int sy = world.surfaceY(8, 8);
        player.teleport(8.5f, sy + 0.05f, 8.5f);
        initialized = true;
    }

    private void update(float dt) {
        input.takeLook(look);
        player.yaw += look[0] * sens;
        player.pitch -= look[1] * sens;
        if (player.pitch > 89f) player.pitch = 89f;
        if (player.pitch < -89f) player.pitch = -89f;

        player.update(dt, input.moveX, input.moveY, input.jump);
        posX = player.x; posY = player.y; posZ = player.z;

        // Raycast dari mata ke arah pandang
        double yr = Math.toRadians(player.yaw), pr = Math.toRadians(player.pitch);
        float cp = (float) Math.cos(pr);
        float dx = cp * (float) Math.sin(yr), dy = (float) Math.sin(pr), dz = -cp * (float) Math.cos(yr);
        hasHit = world.raycast(player.x, player.y + Player.EYE, player.z, dx, dy, dz, REACH, hit);

        breakCd -= dt;
        placeCd -= dt;
        if (hasHit && input.breakHeld && breakCd <= 0f) {
            if (hit.y > 0) {   // lapisan paling bawah (bedrock) tidak bisa dihancurkan
                world.setBlock(hit.x, hit.y, hit.z, Block.AIR);
            }
            breakCd = 0.22f;
        }
        if (hasHit && input.placeHeld && placeCd <= 0f) {
            boolean sameBlock = hit.px == hit.x && hit.py == hit.y && hit.pz == hit.z;
            if (!sameBlock && !player.overlapsBlock(hit.px, hit.py, hit.pz)) {
                int slot = Math.max(0, Math.min(Block.HOTBAR.length - 1, input.selected));
                world.setBlock(hit.px, hit.py, hit.pz, Block.HOTBAR[slot]);
            }
            placeCd = 0.22f;
        }

        // Bangun ulang mesh chunk yang diedit langsung agar terasa responsif
        if (!world.edited.isEmpty()) {
            ArrayList<Chunk> list = new ArrayList<>(world.edited);
            world.edited.clear();
            for (Chunk c : list) {
                if (c.vbo != 0 || c.meshed) meshChunk(c);
            }
        }
    }

    private static int floorDiv16(float v) {
        return ((int) Math.floor(v)) >> 4;
    }

    /** Muat chunk di sekitar pemain, bangun mesh bertahap, buang yang jauh. */
    private void streamChunks() {
        int pcx = floorDiv16(player.x), pcz = floorDiv16(player.z);
        if (pcx != lastCx || pcz != lastCz) {
            lastCx = pcx;
            lastCz = pcz;
            needScan = true;
            unloadFar(pcx, pcz);
        }
        if (!needScan) return;

        boolean work = false;
        int R = renderDist;

        // 1) buat data chunk (radius R+1 agar tetangga mesh selalu ada), maks 2 per frame
        for (int i = 0; i < 2; i++) {
            int bx = 0, bz = 0, bd = Integer.MAX_VALUE;
            for (int dz = -(R + 1); dz <= R + 1; dz++) {
                for (int dx = -(R + 1); dx <= R + 1; dx++) {
                    int d = dx * dx + dz * dz;
                    if (d < bd && world.getChunk(pcx + dx, pcz + dz) == null) {
                        bd = d; bx = pcx + dx; bz = pcz + dz;
                    }
                }
            }
            if (bd == Integer.MAX_VALUE) break;
            world.ensureChunk(bx, bz);
            work = true;
        }

        // 2) bangun mesh chunk terdekat yang tetangganya sudah siap, maks 2 per frame
        for (int i = 0; i < 2; i++) {
            Chunk best = null;
            int bd = Integer.MAX_VALUE;
            for (int dz = -R; dz <= R; dz++) {
                for (int dx = -R; dx <= R; dx++) {
                    int d = dx * dx + dz * dz;
                    if (d >= bd) continue;
                    Chunk c = world.getChunk(pcx + dx, pcz + dz);
                    if (c == null || c.meshed) continue;
                    if (world.getChunk(c.cx - 1, c.cz) == null || world.getChunk(c.cx + 1, c.cz) == null
                            || world.getChunk(c.cx, c.cz - 1) == null || world.getChunk(c.cx, c.cz + 1) == null)
                        continue;
                    best = c;
                    bd = d;
                }
            }
            if (best == null) break;
            meshChunk(best);
            work = true;
        }

        needScan = work;
    }

    private void unloadFar(int pcx, int pcz) {
        int limit = renderDist + 3;
        ArrayList<Chunk> far = new ArrayList<>();
        for (Chunk c : world.chunkValues()) {
            if (Math.max(Math.abs(c.cx - pcx), Math.abs(c.cz - pcz)) > limit) far.add(c);
        }
        for (Chunk c : far) {
            freeVbo(c);
            c.meshed = false;
            if (!c.modified) world.removeChunk(c);   // chunk yang diedit pemain disimpan di memori
        }
    }

    // ================= mesh / VBO =================

    private void meshChunk(Chunk c) {
        world.buildMesh(c, meshList);
        int n = meshList.size;
        if (n == 0) {
            freeVbo(c);
        } else {
            if (c.vbo == 0) {
                int[] id = new int[1];
                GLES20.glGenBuffers(1, id, 0);
                c.vbo = id[0];
            }
            int bytes = n * 4;
            if (bytes > scratch.capacity()) {
                scratch = ByteBuffer.allocateDirect(Math.max(bytes, scratch.capacity() * 2))
                        .order(ByteOrder.nativeOrder());
            }
            scratch.clear();
            FloatBuffer fb = scratch.asFloatBuffer();
            fb.put(meshList.data, 0, n);
            fb.position(0);
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, c.vbo);
            GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, bytes, fb, GLES20.GL_STATIC_DRAW);
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0);
            c.vertexCount = n / 6;
        }
        if (n == 0) c.vertexCount = 0;
        c.meshed = true;
    }

    private void freeVbo(Chunk c) {
        if (c.vbo != 0) {
            GLES20.glDeleteBuffers(1, new int[]{c.vbo}, 0);
            c.vbo = 0;
        }
        c.vertexCount = 0;
    }

    // ================= render =================

    private void render() {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT | GLES20.GL_DEPTH_BUFFER_BIT);

        double yr = Math.toRadians(player.yaw), pr = Math.toRadians(player.pitch);
        float cp = (float) Math.cos(pr);
        float fx = cp * (float) Math.sin(yr), fy = (float) Math.sin(pr), fz = -cp * (float) Math.cos(yr);
        float ex = player.x, ey = player.y + Player.EYE, ez = player.z;

        float far = (renderDist + 2) * World.CS + 16f;
        Matrix.perspectiveM(proj, 0, 70f, aspect, 0.1f, far);
        Matrix.setLookAtM(view, 0, ex, ey, ez, ex + fx, ey + fy, ez + fz, 0f, 1f, 0f);
        Matrix.multiplyMM(vp, 0, proj, 0, view, 0);

        // ---- blok ----
        GLES20.glUseProgram(prog);
        GLES20.glUniformMatrix4fv(uMVP, 1, false, vp, 0);
        GLES20.glUniform3f(uCam, ex, ey, ez);
        float fogEnd = renderDist * World.CS;
        GLES20.glUniform1f(uFogEnd, fogEnd);
        GLES20.glUniform1f(uFogStart, fogEnd * 0.55f);
        GLES20.glUniform3f(uFogColor, SKY_R, SKY_G, SKY_B);
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0);
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texture);
        GLES20.glUniform1i(uTex, 0);
        GLES20.glEnableVertexAttribArray(aPos);
        GLES20.glEnableVertexAttribArray(aUV);
        GLES20.glEnableVertexAttribArray(aShade);

        float maxDist = (renderDist + 1) * World.CS + 8f;
        for (Chunk c : world.chunkValues()) {
            if (c.vbo == 0 || c.vertexCount == 0) continue;
            float cx = c.cx * World.CS + 8f - ex, cy = 32f - ey, cz = c.cz * World.CS + 8f - ez;
            if (cx * cx + cz * cz > maxDist * maxDist) continue;
            if (cx * fx + cy * fy + cz * fz < -36f) continue;   // di belakang kamera
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, c.vbo);
            GLES20.glVertexAttribPointer(aPos, 3, GLES20.GL_FLOAT, false, 24, 0);
            GLES20.glVertexAttribPointer(aUV, 2, GLES20.GL_FLOAT, false, 24, 12);
            GLES20.glVertexAttribPointer(aShade, 1, GLES20.GL_FLOAT, false, 24, 20);
            GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, c.vertexCount);
        }
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0);
        GLES20.glDisableVertexAttribArray(aPos);
        GLES20.glDisableVertexAttribArray(aUV);
        GLES20.glDisableVertexAttribArray(aShade);

        // ---- garis tepi blok yang dibidik ----
        if (hasHit && !paused) {
            GLES20.glUseProgram(lineProg);
            System.arraycopy(vp, 0, tmp, 0, 16);
            Matrix.translateM(tmp, 0, hit.x, hit.y, hit.z);
            GLES20.glUniformMatrix4fv(luMVP, 1, false, tmp, 0);
            GLES20.glEnableVertexAttribArray(laPos);
            outline.position(0);
            GLES20.glVertexAttribPointer(laPos, 3, GLES20.GL_FLOAT, false, 12, outline);
            GLES20.glLineWidth(3f);
            GLES20.glDrawArrays(GLES20.GL_LINES, 0, 24);
            GLES20.glDisableVertexAttribArray(laPos);
        }
    }

    // ================= helper shader =================

    private static int compile(int type, String src) {
        int s = GLES20.glCreateShader(type);
        GLES20.glShaderSource(s, src);
        GLES20.glCompileShader(s);
        int[] ok = new int[1];
        GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0);
        if (ok[0] == 0) {
            String log = GLES20.glGetShaderInfoLog(s);
            GLES20.glDeleteShader(s);
            throw new RuntimeException("Shader gagal dikompilasi: " + log);
        }
        return s;
    }

    private static int program(String vs, String fs) {
        int p = GLES20.glCreateProgram();
        GLES20.glAttachShader(p, compile(GLES20.GL_VERTEX_SHADER, vs));
        GLES20.glAttachShader(p, compile(GLES20.GL_FRAGMENT_SHADER, fs));
        GLES20.glLinkProgram(p);
        int[] ok = new int[1];
        GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, ok, 0);
        if (ok[0] == 0) throw new RuntimeException("Program gagal di-link: " + GLES20.glGetProgramInfoLog(p));
        return p;
    }
}
