package com.nolicense.craft;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Shader;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Build;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;

/** Utilitas UI dan pengaturan yang dipakai bersama oleh semua layar. */
public final class Ui {
    private Ui() {}

    // ---------- pengaturan ----------
    private static SharedPreferences sp(Context c) {
        return c.getSharedPreferences("settings", Context.MODE_PRIVATE);
    }

    public static int renderDist(Context c) { return sp(c).getInt("render_dist", 4); }
    public static int sensitivity(Context c) { return sp(c).getInt("sens", 8); }
    public static boolean showFps(Context c) { return sp(c).getBoolean("show_fps", true); }

    public static void saveRenderDist(Context c, int v) { sp(c).edit().putInt("render_dist", v).apply(); }
    public static void saveSensitivity(Context c, int v) { sp(c).edit().putInt("sens", v).apply(); }
    public static void saveShowFps(Context c, boolean v) { sp(c).edit().putBoolean("show_fps", v).apply(); }

    // ---------- tampilan ----------
    public static int dp(Context c, float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v,
                c.getResources().getDisplayMetrics());
    }

    @SuppressWarnings("deprecation")
    public static void immersive(Activity a) {
        a.getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams lp = a.getWindow().getAttributes();
            lp.layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            a.getWindow().setAttributes(lp);
        }
    }

    /** Latar menu: tile tanah yang diulang dan digelapkan. */
    public static BitmapDrawable dirtBackground(Context c) {
        Bitmap b = TextureAtlas.tileBitmap(Block.T_DIRT, dp(c, 64));
        BitmapDrawable d = new BitmapDrawable(c.getResources(), b);
        d.setTileModeXY(Shader.TileMode.REPEAT, Shader.TileMode.REPEAT);
        d.setColorFilter(new PorterDuffColorFilter(0xFF555555, PorterDuff.Mode.MULTIPLY));
        return d;
    }

    private static GradientDrawable box(int fill, int stroke, Context c) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setStroke(dp(c, 2), stroke);
        return g;
    }

    public static Button button(Context c, String text, View.OnClickListener l) {
        Button b = new Button(c);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        b.setAllCaps(false);
        b.setShadowLayer(2, 2, 2, 0xFF222222);
        StateListDrawable s = new StateListDrawable();
        s.addState(new int[]{android.R.attr.state_pressed}, box(0xFF6B7BC4, 0xFFFFFFFF, c));
        s.addState(new int[]{}, box(0xFF7A7A7A, 0xFF000000, c));
        b.setBackground(s);
        b.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(c, 300), dp(c, 52));
        lp.gravity = Gravity.CENTER_HORIZONTAL;
        lp.topMargin = dp(c, 10);
        b.setLayoutParams(lp);
        return b;
    }
}
