package com.nolicense.craft;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.widget.CheckBox;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

/** Pengaturan: jarak pandang, sensitivitas kamera, tampilkan FPS. */
public class SettingsActivity extends Activity {

    private TextView rdLabel, sensLabel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Ui.immersive(this);

        FrameLayout root = new FrameLayout(this);
        root.setBackground(Ui.dirtBackground(this));

        ScrollView scroll = new ScrollView(this);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(Ui.dp(this, 40), Ui.dp(this, 20), Ui.dp(this, 40), Ui.dp(this, 20));

        TextView title = label("Pengaturan", 28);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        col.addView(title);

        // Jarak pandang 2..8 chunk
        rdLabel = label("", 16);
        rdLabel.setPadding(0, Ui.dp(this, 16), 0, 0);
        col.addView(rdLabel);
        SeekBar rd = new SeekBar(this);
        rd.setMax(6);
        rd.setProgress(Ui.renderDist(this) - 2);
        updateRd(Ui.renderDist(this));
        rd.setOnSeekBarChangeListener(new Simple() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean user) {
                Ui.saveRenderDist(SettingsActivity.this, p + 2);
                updateRd(p + 2);
            }
        });
        col.addView(rd);

        // Sensitivitas 1..20
        sensLabel = label("", 16);
        sensLabel.setPadding(0, Ui.dp(this, 16), 0, 0);
        col.addView(sensLabel);
        SeekBar sens = new SeekBar(this);
        sens.setMax(19);
        sens.setProgress(Ui.sensitivity(this) - 1);
        updateSens(Ui.sensitivity(this));
        sens.setOnSeekBarChangeListener(new Simple() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean user) {
                Ui.saveSensitivity(SettingsActivity.this, p + 1);
                updateSens(p + 1);
            }
        });
        col.addView(sens);

        CheckBox fps = new CheckBox(this);
        fps.setText("Tampilkan FPS dan koordinat");
        fps.setTextColor(Color.WHITE);
        fps.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        fps.setChecked(Ui.showFps(this));
        fps.setOnCheckedChangeListener((b, on) -> Ui.saveShowFps(this, on));
        fps.setPadding(0, Ui.dp(this, 16), 0, Ui.dp(this, 8));
        col.addView(fps);

        col.addView(Ui.button(this, "Selesai", v -> finish()));

        scroll.addView(col);
        root.addView(scroll, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(root);
    }

    private TextView label(String text, int sp) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(Color.WHITE);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setShadowLayer(2, 2, 2, 0xFF000000);
        return t;
    }

    private void updateRd(int v) {
        rdLabel.setText("Jarak Pandang: " + v + " chunk" + (v >= 7 ? " (berat di HP lemah)" : ""));
    }

    private void updateSens(int v) {
        sensLabel.setText("Sensitivitas Kamera: " + v);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) Ui.immersive(this);
    }

    /** SeekBar listener dengan metode kosong agar cukup override satu fungsi. */
    private abstract static class Simple implements SeekBar.OnSeekBarChangeListener {
        @Override public void onStartTrackingTouch(SeekBar s) {}
        @Override public void onStopTrackingTouch(SeekBar s) {}
    }
}
