package com.nolicense.craft;

import android.app.Activity;
import android.app.AlertDialog;
import android.opengl.GLSurfaceView;
import android.os.Bundle;
import android.view.WindowManager;
import android.widget.FrameLayout;

/** Layar permainan: GLSurfaceView + lapisan kontrol sentuh. */
public class GameActivity extends Activity {
    private GLSurfaceView glView;
    private GameRenderer renderer;
    private ControlsView controls;
    private AlertDialog pauseDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        Ui.immersive(this);

        long seed = getIntent().getLongExtra("seed", System.nanoTime());
        World world = new World(seed);
        Input input = new Input();
        float sens = Ui.sensitivity(this) * 0.02f;   // derajat per piksel
        renderer = new GameRenderer(world, input, Ui.renderDist(this), sens);

        glView = new GLSurfaceView(this);
        glView.setEGLContextClientVersion(2);
        glView.setEGLConfigChooser(8, 8, 8, 0, 16, 0);
        glView.setRenderer(renderer);

        controls = new ControlsView(this, input, renderer, Ui.showFps(this), this::showPauseMenu);

        FrameLayout root = new FrameLayout(this);
        root.addView(glView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        root.addView(controls, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(root);
    }

    private void showPauseMenu() {
        if (pauseDialog != null && pauseDialog.isShowing()) return;
        renderer.paused = true;
        pauseDialog = new AlertDialog.Builder(this)
                .setTitle("Permainan Dijeda")
                .setItems(new String[]{"Lanjutkan", "Keluar ke Menu Utama"}, (d, which) -> {
                    if (which == 1) finish();
                })
                .setOnDismissListener(d -> {
                    renderer.paused = false;
                    Ui.immersive(this);
                })
                .show();
    }

    @Override
    public void onBackPressed() {
        showPauseMenu();
    }

    @Override
    protected void onPause() {
        super.onPause();
        controls.releaseAll();
        glView.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        glView.onResume();
        Ui.immersive(this);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) Ui.immersive(this);
    }
}
