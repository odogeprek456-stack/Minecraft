package com.nolicense.craft;

/** Definisi blok. Semua tekstur dibuat sendiri secara prosedural (lihat TextureAtlas). */
public final class Block {
    public static final byte AIR = 0, GRASS = 1, DIRT = 2, STONE = 3, SAND = 4,
            WOOD = 5, LEAVES = 6, PLANKS = 7, COBBLE = 8, BEDROCK = 9;

    /** Blok yang tersedia di hotbar. */
    public static final byte[] HOTBAR = {GRASS, DIRT, STONE, SAND, WOOD, LEAVES, PLANKS, COBBLE};

    public static final int T_GRASS_TOP = 0, T_GRASS_SIDE = 1, T_DIRT = 2, T_STONE = 3,
            T_SAND = 4, T_WOOD_SIDE = 5, T_WOOD_TOP = 6, T_LEAVES = 7, T_PLANKS = 8,
            T_COBBLE = 9, T_BEDROCK = 10;

    /** [blok][0=atas, 1=samping, 2=bawah] -> indeks tile di atlas. */
    private static final int[][] TILES = {
            {0, 0, 0},
            {T_GRASS_TOP, T_GRASS_SIDE, T_DIRT},
            {T_DIRT, T_DIRT, T_DIRT},
            {T_STONE, T_STONE, T_STONE},
            {T_SAND, T_SAND, T_SAND},
            {T_WOOD_TOP, T_WOOD_SIDE, T_WOOD_TOP},
            {T_LEAVES, T_LEAVES, T_LEAVES},
            {T_PLANKS, T_PLANKS, T_PLANKS},
            {T_COBBLE, T_COBBLE, T_COBBLE},
            {T_BEDROCK, T_BEDROCK, T_BEDROCK},
    };

    private static final String[] NAMES = {
            "Udara", "Rumput", "Tanah", "Batu", "Pasir", "Kayu", "Daun", "Papan", "Batu Bulat", "Batu Dasar"
    };

    private Block() {}

    public static int tile(int block, int face) {
        return TILES[block][face];
    }

    public static int iconTile(int block) {
        return TILES[block][1];
    }

    public static String name(int block) {
        return NAMES[block];
    }
}
