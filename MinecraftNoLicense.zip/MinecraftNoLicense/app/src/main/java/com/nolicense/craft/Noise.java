package com.nolicense.craft;

/** Value noise 2D sederhana berbasis seed. */
public final class Noise {
    private final long seed;

    public Noise(long seed) {
        this.seed = seed;
    }

    /** Angka acak deterministik 0..1 untuk koordinat bulat. */
    public float rand(int x, int z) {
        long h = seed * 0x9E3779B97F4A7C15L;
        h ^= (long) x * 0x27D4EB2DL;
        h *= 0xFF51AFD7ED558CCDL;
        h ^= (h >>> 32);
        h ^= (long) z * 0x165667B1L;
        h *= 0xC4CEB9FE1A85EC53L;
        h ^= (h >>> 29);
        return ((h >>> 40) & 0xFFFFFFL) / (float) 0x1000000;
    }

    private static float smooth(float t) {
        return t * t * (3f - 2f * t);
    }

    public float value(float x, float z) {
        int xi = (int) Math.floor(x);
        int zi = (int) Math.floor(z);
        float fx = smooth(x - xi);
        float fz = smooth(z - zi);
        float a = rand(xi, zi);
        float b = rand(xi + 1, zi);
        float c = rand(xi, zi + 1);
        float d = rand(xi + 1, zi + 1);
        float top = a + (b - a) * fx;
        float bot = c + (d - c) * fx;
        return top + (bot - top) * fz;
    }

    public float fbm(float x, float z, int octaves) {
        float sum = 0f, amp = 1f, norm = 0f, f = 1f;
        for (int i = 0; i < octaves; i++) {
            sum += value(x * f + i * 17.3f, z * f - i * 9.1f) * amp;
            norm += amp;
            amp *= 0.5f;
            f *= 2f;
        }
        return sum / norm;
    }
}
