package com.nolicense.craft;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Random;

/** Menu utama: hanya "Buat Dunia" dan "Pengaturan". */
public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Ui.immersive(this);

        FrameLayout root = new FrameLayout(this);
        root.setBackground(Ui.dirtBackground(this));

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER);
        col.setPadding(Ui.dp(this, 16), Ui.dp(this, 8), Ui.dp(this, 16), Ui.dp(this, 8));

        TextView title = new TextView(this);
        title.setText("MINECRAFT NO-LICENSE");
        title.setTextColor(Color.WHITE);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 34);
        title.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        title.setGravity(Gravity.CENTER);
        title.setShadowLayer(4, 4, 4, 0xFF000000);
        col.addView(title);

        TextView sub = new TextView(this);
        sub.setText("- DEMO -");
        sub.setTextColor(0xFFFFFF55);
        sub.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        sub.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        sub.setGravity(Gravity.CENTER);
        sub.setShadowLayer(3, 3, 3, 0xFF000000);
        col.addView(sub);

        TextView gap = new TextView(this);
        gap.setHeight(Ui.dp(this, 18));
        col.addView(gap);

        col.addView(Ui.button(this, "Buat Dunia", v -> showCreateWorld()));
        col.addView(Ui.button(this, "Pengaturan",
                v -> startActivity(new Intent(this, SettingsActivity.class))));

        TextView foot = new TextView(this);
        foot.setText("Game fan-made independen. Tidak berafiliasi dengan Mojang / Microsoft.");
        foot.setTextColor(0xFFBBBBBB);
        foot.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        foot.setGravity(Gravity.CENTER);
        foot.setPadding(0, Ui.dp(this, 22), 0, 0);
        col.addView(foot);

        root.addView(col, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(root);
    }

    private void showCreateWorld() {
        final EditText seedBox = new EditText(this);
        seedBox.setHint("Seed (kosongkan untuk acak)");
        seedBox.setSingleLine(true);
        seedBox.setInputType(InputType.TYPE_CLASS_TEXT);
        LinearLayout wrap = new LinearLayout(this);
        wrap.setPadding(Ui.dp(this, 20), Ui.dp(this, 8), Ui.dp(this, 20), 0);
        wrap.addView(seedBox, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        new AlertDialog.Builder(this)
                .setTitle("Buat Dunia Baru")
                .setView(wrap)
                .setPositiveButton("Buat", (d, w) -> {
                    String s = seedBox.getText().toString().trim();
                    long seed;
                    if (s.isEmpty()) {
                        seed = new Random().nextLong();
                    } else {
                        try {
                            seed = Long.parseLong(s);
                        } catch (NumberFormatException e) {
                            seed = s.hashCode();
                        }
                    }
                    Intent i = new Intent(this, GameActivity.class);
                    i.putExtra("seed", seed);
                    startActivity(i);
                })
                .setNegativeButton("Batal", null)
                .show();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) Ui.immersive(this);
    }
}
