package com.nolicense.craft;

import android.graphics.Bitmap;

import java.util.Random;

/** Atlas tekstur 4x4 tile (16 px) yang digambar sendiri lewat kode - tanpa aset berhak cipta. */
public final class TextureAtlas {
    public static final int TILE = 16, COLS = 4, SIZE = 64;
    private static Bitmap cached;

    private TextureAtlas() {}

    public static synchronized Bitmap get() {
        if (cached == null) {
            int[] px = new int[SIZE * SIZE];
            for (int t = 0; t <= Block.T_BEDROCK; t++) paint(px, t);
            cached = Bitmap.createBitmap(px, SIZE, SIZE, Bitmap.Config.ARGB_8888);
        }
        return cached;
    }

    /** Satu tile, diperbesar tanpa filter (pixel tajam). */
    public static Bitmap tileBitmap(int tile, int px) {
        Bitmap one = Bitmap.createBitmap(get(), (tile % COLS) * TILE, (tile / COLS) * TILE, TILE, TILE);
        return Bitmap.createScaledBitmap(one, px, px, false);
    }

    private static int clamp(int v) {
        return v < 0 ? 0 : (v > 255 ? 255 : v);
    }

    private static int rgb(int r, int g, int b) {
        return 0xFF000000 | (clamp(r) << 16) | (clamp(g) << 8) | clamp(b);
    }

    private static int cellHash(int a, int b) {
        int h = a * 73856093 ^ b * 19349663;
        h ^= (h >>> 13);
        return h & 0x7FFFFFFF;
    }

    private static void paint(int[] px, int tile) {
        Random rnd = new Random(tile * 7919L + 13);
        int ox = (tile % COLS) * TILE, oy = (tile / COLS) * TILE;
        for (int y = 0; y < TILE; y++) {
            for (int x = 0; x < TILE; x++) {
                int n = rnd.nextInt(33) - 16;
                int c;
                switch (tile) {
                    case Block.T_GRASS_TOP:
                        c = rgb(88 + n / 2, 156 + n, 58 + n / 2);
                        break;
                    case Block.T_GRASS_SIDE:
                        if (y < 3 || (y == 3 && x % 3 == 0)) c = rgb(88 + n / 2, 156 + n, 58 + n / 2);
                        else c = rgb(134 + n, 96 + n, 67 + n);
                        break;
                    case Block.T_DIRT:
                        c = rgb(134 + n, 96 + n, 67 + n);
                        break;
                    case Block.T_STONE:
                        c = rgb(125 + n, 125 + n, 125 + n);
                        break;
                    case Block.T_SAND:
                        c = rgb(219 + n / 2, 207 + n / 2, 163 + n / 2);
                        break;
                    case Block.T_WOOD_SIDE: {
                        int d = (x % 4 == 0) ? -22 : 0;
                        c = rgb(104 + n / 2 + d, 82 + n / 2 + d, 50 + n / 2 + d);
                        break;
                    }
                    case Block.T_WOOD_TOP: {
                        double dx = x - 7.5, dy = y - 7.5;
                        double d = Math.sqrt(dx * dx + dy * dy);
                        if (d > 7) c = rgb(104 + n / 2, 82 + n / 2, 50 + n / 2);
                        else if (((int) d) % 2 == 0) c = rgb(170 + n / 3, 140 + n / 3, 90 + n / 3);
                        else c = rgb(150 + n / 3, 120 + n / 3, 75 + n / 3);
                        break;
                    }
                    case Block.T_LEAVES: {
                        int d = ((x * 5 + y * 11) % 7 == 0) ? -28 : 0;
                        c = rgb(40 + n / 2 + d, 115 + n + d, 35 + n / 2 + d);
                        break;
                    }
                    case Block.T_PLANKS: {
                        int d = 0;
                        if (y % 4 == 3) d = -28;
                        else if ((((y / 4) % 2 == 0) ? x % 8 : (x + 4) % 8) == 0) d = -22;
                        c = rgb(157 + n / 3 + d, 128 + n / 3 + d, 79 + n / 3 + d);
                        break;
                    }
                    case Block.T_COBBLE: {
                        int shift = ((y / 4) % 2) * 2;
                        int cell = cellHash((x + shift) / 4, y / 4) % 40;
                        int v = 100 + cell + n / 2;
                        if (y % 4 == 0 || (x + shift) % 4 == 0) v -= 32;
                        c = rgb(v, v, v);
                        break;
                    }
                    default: { // bedrock
                        int v = 40 + rnd.nextInt(50);
                        c = rgb(v, v, v);
                    }
                }
                px[(oy + y) * SIZE + ox + x] = c;
            }
        }
    }
}
