package com.nolicense.craft;

/** Potongan dunia 16 x 64 x 16 blok. */
public final class Chunk {
    public final int cx, cz;
    public final byte[] blocks = new byte[World.CS * World.H * World.CS];

    /** true jika pemain pernah mengubah chunk ini (tidak dibuang saat jauh). */
    public boolean modified = false;
    /** true jika mesh sudah dibangun dan diunggah ke GPU. */
    public boolean meshed = false;

    // Data GPU (diisi renderer)
    public int vbo = 0;
    public int vertexCount = 0;

    public Chunk(int cx, int cz) {
        this.cx = cx;
        this.cz = cz;
    }
}
